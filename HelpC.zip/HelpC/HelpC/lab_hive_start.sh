#!/bin/bash

kinit -kt /otds/platform/keytabs/hive.service.keytab hive/mtl-hive01x.cnppd.lab@CNPPD.LAB

#ADMIN="giri.nadarajah@cn.ca,ananthan.kathiramalai@cn.ca"
ADMIN="giri.nadarajah@cn.ca"




curl -u admin:admin -H "X-Requested-By: ambari" -X GET https://mtl-bdmgmt01x.cnppd.lab:8443/api/v1/clusters/techsbx_hdp/components/"HIVE_SERVER"|grep '"state" : "STARTED"' > /home/hive/status.txt
curl -u admin:admin -H "X-Requested-By: ambari" -X GET https://mtl-bdmgmt01x.cnppd.lab:8443/api/v1/clusters/techsbx_hdp/components/"HIVE_METASTORE"|grep '"state" : "STARTED"' >> /home/hive/status.txt

if [ -s /home/hive/status.txt ]
then

{
beeline -f /home/hive/beeline_test.sql > /home/hive/beeline_status.txt

_file="$1"
[ $# -eq 0 ] && { echo "Usage: $0 filename"; exit 1; }
[ ! -f "$_file" ] && { echo "Error: $0 file not found."; exit 2; }

if [ -s "$_file" ]
then
    {   #echo "beeline running NO ISSUE"
        #mail -s "beeline running NO ISSUE " $ADMIN  </home/hive/beeline_status.txt
		
                        #echo "Check 1ST HIVESEVER"
                        ###########################
                                beeline -n hive -u 'jdbc:hive2://mtl-hive01x.cnppd.lab:10000/;transportMode=binary;principal=hive/mtl-hive01x.cnppd.lab@CNPPD.LAB' -f /home/hive/beeline_test.sql > /home/hive/hiveserver1.txt
                                        if [ -s /home/hive/hiveserver1.txt ]
                                                then {
                                                         echo "beeline running NO ISSUE in HIVESERVER 1st"
                                                        }
                                                else
                                                        echo "Need to start the hive server 1"
                                                        mail -s " ******** Beeline is not working, - Need to start the hive services in mtl-hive01x.cnppd.lab *** please STANDBY for further e-mail  " $ADMIN  < /home/hive/hiveserver1.txt

                                                        curl -u admin:admin -i -H 'X-Requested-By: ambari' -X PUT -d '{"RequestInfo":{"context":"Stop Component"},"Body":{"HostRoles":{"state":"INSTALLED"}}}' "https://mtl-bdmgmt01x.cnppd.lab:8443/api/v1/clusters/techsbx_hdp/hosts/mtl-hive01x.cnppd.lab/host_components/HIVE_SERVER" 
														                                                                                                                                                       
 
                                                        sleep 2m

                                                        curl -u admin:admin -i -H 'X-Requested-By: ambari' -X PUT -d '{"RequestInfo":{"context":"Stop Component"},"Body":{"HostRoles":{"state":"STARTED"}}}' "https://mtl-bdmgmt01x.cnppd.lab:8443/api/v1/clusters/techsbx_hdp/hosts/mtl-hive01x.cnppd.lab/host_components/HIVE_SERVER"
                                                        sleep 2m

                                                        beeline -n hive -u 'jdbc:hive2://mtl-hive01x.cnppd.lab:10000/;transportMode=binary;principal=hive/mtl-hive01x.cnppd.lab@CNPPD.LAB' -f /home/hive/beeline_test.sql > /home/hive/hiveserver1.txt
                                                        mail -s "******** Hive has been restarted, beeline is up and running " $ADMIN  < /home/hive/hiveserver1.txt

                                                fi

                        #echo "Check 2ND HIVESERVER"
                        ############################
                                beeline -n hive -u 'jdbc:hive2://mtl-solr01x.cnppd.lab:10000/;transportMode=binary;principal=hive/mtl-solr01x.cnppd.lab@CNPPD.LAB' -f /home/hive/beeline_test.sql > /home/hive/hiveserver2.txt
                                        if [ -s /home/hive/hiveserver2.txt ]
                                                then    {

                                                                echo "beeline running NO ISSUE HIVESERVER 2nd"
                                                         }
                                                else
                                                                 echo "Need to start the hive server 2"
                                                                mail -s " ******** Beeline is not working, Need to start the hive services in mtl-solr01x.cnppd.lab *** please STANDBY for further e-mail " $ADMIN  < /home/hive/hiveserver2.txt

                                                                curl -u otdsi-stgmc-bot:f129cef520 -i -H 'X-Requested-By: ambari' -X PUT -d '{"RequestInfo":{"context":"Stop Component"},"Body":{"HostRoles":{"state":"INSTALLED"}}}' "https://mtl-bdmgmt01x.cnppd.lab:8443/api/v1/clusters/techsbx_hdp/hosts/mtl-solr01x.cnppd.lab/host_components/HIVE_SERVER"

                                                                sleep 2m

                                                                curl -u otdsi-stgmc-bot:f129cef520 -i -H 'X-Requested-By: ambari' -X PUT -d '{"RequestInfo":{"context":"Start Component"},"Body":{"HostRoles":{"state":"STARTED"}}}' "https://mtl-bdmgmt01x.cnppd.lab:8443/api/v1/clusters/techsbx_hdp/hosts/mtl-solr01x.cnppd.lab/host_components/HIVE_SERVER"
                                                                sleep 2m
                                                                 beeline -n hive -u 'jdbc:hive2://mtl-solr01x.cnppd.lab:10000/;transportMode=binary;principal=hive/mtl-solr01x.cnppd.lab@CNPPD.LAB' -f /home/hive/beeline_test.sql > /home/hive/hiveserver2.txt
                                                        mail -s "******** Hive has been restarted, beeline is up and running " $ADMIN  < /home/hive/hiveserver2.txt
                                                fi


		
	}
else
        # "file is empty."
      # curl -u admin:admin -H "X-Requested-By: ambari" -X GET https://mtl-hdpmgt51d.cn.ca:8443/api/v1/clusters/devmc_hdp/services/HIVE |grep -e "component_name"

		mail -s " ******** Beeline is not working, please STANDBY for further e-mail " $ADMIN  </home/hive/beeline_status.txt
		
        curl -u admin:admin -i -H 'X-Requested-By: ambari' -X PUT -d '{"RequestInfo": {"context" :"Stop HIVE via REST"}, "Body": {"ServiceInfo": {"state": "INSTALLED"}}}' https://mtl-bdmgmt01x.cnppd.lab:8443/api/v1/clusters/techsbx_hdp/services/HIVE

        sleep 7m # Waits 7 minutes

        curl -u admin:admin -i -H 'X-Requested-By: ambari' -X PUT -d '{"RequestInfo": {"context" :"Start HIVE via REST"}, "Body": {"ServiceInfo": {"state": "STARTED"}}}' https://mtl-bdmgmt01x.cnppd.lab:8443/api/v1/clusters/techsbx_hdp/services/HIVE

        sleep 3m

        beeline -f /home/hive/beeline_test.sql > /home/hive/beeline_status.txt
        mail -s "Hive has been restarted, beeline is up and running " $ADMIN  </home/hive/beeline_status.txt

fi
