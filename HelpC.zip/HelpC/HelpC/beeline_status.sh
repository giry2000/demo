/home/hive/hive_startup.sh /home/hive/beeline_status.txt
