#!/bin/bash

#ADMIN="giri.nadarajah@cn.ca"
ADMIN="giri.nadarajah@cn.ca,ananthan.kathiramalai@cn.ca,mahammad.fareedShaik@cn.ca, kavyasree.ponne@cn.ca"

N=60


declare -a fileSystemDirectoryList=("/var/log/hadoop/")

for i in "${fileSystemDirectoryList[@]}"
do
    echo "Checking up more $N days old files  $i ..."

    find ${i} -type f -mtime +$N -exec ls -larth {}  \; > /hadoop/`hostname`_MoreThan60Days.txt
    find ${i} -type f -mtime +$N -exec rm -rf {} \;	

    mail -s "  ****The list of more than $N days /var/log/hadoop/ files has been removed from `hostname`  ******** " -a "/hadoop/`hostname`_MoreThan60Days.txt"  $ADMIN  < "/hadoop/`hostname`_MoreThan60Days.txt"
done
