#!/bin/bash
kinit -kt /otds/platform/keytabs/hive.service.keytab hive/mtl-master82p.cn.ca@CN.CA

ADMIN="giri.nadarajah@cn.ca,ananthan.kathiramalai@cn.ca,harish.terli@cn.ca,yongsheng.tang@cn.ca"
#ADMIN="giri.nadarajah@cn.ca"


curl -u otdsi-prdmc-bot:mGpBevSEK16Vx3sP -H "X-Requested-By: ambari" -X GET https://mtl-hdpmgt81p.cn.ca:8443/api/v1/clusters/prdmchq_hdp/components/"HIVE_SERVER"|grep '"state" : "STARTED"' > /home/hive/status.txt
curl -u otdsi-prdmc-bot:mGpBevSEK16Vx3sP -H "X-Requested-By: ambari" -X GET https://mtl-hdpmgt81p.cn.ca:8443/api/v1/clusters/prdmchq_hdp/components/"HIVE_METASTORE"|grep '"state" : "STARTED"' >> /home/hive/status.txt


if [ -s /home/hive/status.txt ]
then

{
beeline -f /home/hive/beeline_test.sql > /home/hive/beeline_status.txt

_file="$1"
[ $# -eq 0 ] && { echo "Usage: $0 filename"; exit 1; }
[ ! -f "$_file" ] && { echo "Error: $0 file not found."; exit 2; }

if [ -s "$_file" ]
then
       {
			#echo "Check 1ST HIVESEVER"
			###########################	
				beeline -n hive -u 'jdbc:hive2://mtl-master82p.cn.ca:10000/;transportMode=binary;principal=hive/mtl-master82p.cn.ca@CN.CA' -f /home/hive/beeline_test.sql > /home/hive/hiveserver1.txt
					if [ -s /home/hive/hiveserver1.txt ]
						then {	
							 echo "beeline running NO ISSUE in HIVESERVER 1st"
							} 
						else 	 
							echo "Need to start the hive server 1"
							mail -s " ****PRODHQ**** Beeline is not working, hive service will be restarting  in mtl-master82p.cn.ca ***** please STANDBY for further e-mail " $ADMIN  < /home/hive/hiveserver1.txt

							curl -u otdsi-prdmc-bot:mGpBevSEK16Vx3sP -i -H 'X-Requested-By: ambari' -X PUT -d '{"RequestInfo":{"context":"Stop Component"},"Body":{"HostRoles":{"state":"INSTALLED"}}}' "https://mtl-hdpmgt81p.cn.ca:8443/api/v1/clusters/prdmchq_hdp/hosts/mtl-master82p.cn.ca/host_components/HIVE_SERVER"

							sleep 3m								

							curl -u otdsi-prdmc-bot:mGpBevSEK16Vx3sP -i -H 'X-Requested-By: ambari' -X PUT -d '{"RequestInfo":{"context":"Stop Component"},"Body":{"HostRoles":{"state":"STARTED"}}}' "https://mtl-hdpmgt81p.cn.ca:8443/api/v1/clusters/prdmchq_hdp/hosts/mtl-master82p.cn.ca/host_components/HIVE_SERVER"
							sleep 5m

							beeline -n hive -u 'jdbc:hive2://mtl-master82p.cn.ca:10000/;transportMode=binary;principal=hive/mtl-master82p.cn.ca@CN.CA' -f /home/hive/beeline_test.sql > /home/hive/hiveserver1.txt
                                                        mail -s "****PRODHQ**** Hive has been restarted, beeline is working " $ADMIN  < /home/hive/hiveserver1.txt

						fi

			#echo "Check 2ND HIVESERVER"
			############################
				beeline -n hive -u 'jdbc:hive2://mtl-master83p.cn.ca:10000/;transportMode=binary;principal=hive/mtl-master83p.cn.ca@CN.CA' -f /home/hive/beeline_test.sql > /home/hive/hiveserver2.txt
					if [ -s /home/hive/hiveserver2.txt ]
						then	{

								echo "beeline running NO ISSUE HIVESERVER 2nd"
							 } 
						else 	
								 echo "Need to start the hive server 2"
								mail -s " ****PRODHQ**** Beeline is not working, hive service will be restarting  in mtl-master83p.cn.ca  ******** please STANDBY for further e-mail " $ADMIN  < /home/hive/hiveserver2.txt

								curl -u otdsi-prdmc-bot:mGpBevSEK16Vx3sP -i -H 'X-Requested-By: ambari' -X PUT -d '{"RequestInfo":{"context":"Stop Component"},"Body":{"HostRoles":{"state":"INSTALLED"}}}' "https://mtl-hdpmgt81p.cn.ca:8443/api/v1/clusters/prdmchq_hdp/hosts/mtl-master83p.cn.ca/host_components/HIVE_SERVER"

								sleep 3m

								curl -u otdsi-prdmc-bot:mGpBevSEK16Vx3sP -i -H 'X-Requested-By: ambari' -X PUT -d '{"RequestInfo":{"context":"Start Component"},"Body":{"HostRoles":{"state":"STARTED"}}}' "https://mtl-hdpmgt81p.cn.ca:8443/api/v1/clusters/prdmchq_hdp/hosts/mtl-master83p.cn.ca/host_components/HIVE_SERVER"
								sleep 5m
								 beeline -n hive -u 'jdbc:hive2://mtl-master83p.cn.ca:10000/;transportMode=binary;principal=hive/mtl-master83p.cn.ca@CN.CA' -f /home/hive/beeline_test.sql > /home/hive/hiveserver2.txt
							mail -s "****PRODHQ**** Hive has been restarted, beeline is working " $ADMIN  < /home/hive/hiveserver2.txt	
						fi


		
		}

else
        # "file is empty."
  
        mail -s " ****PRODHQ**** Beeline is not working, hive service will be restarting ***** please STANDBY for further e-mail " $ADMIN  </home/hive/beeline_status.txt

curl -u otdsi-prdmc-bot:mGpBevSEK16Vx3sP -i -H 'X-Requested-By: ambari' -X PUT -d '{"RequestInfo": {"context" :"Stop HIVE via REST"}, "Body": {"ServiceInfo": {"state": "INSTALLED"}}}' https://mtl-hdpmgt81p.cn.ca:8443/api/v1/clusters/prdmchq_hdp/services/HIVE

        sleep 3m # Waits 3 minutes

curl -u otdsi-prdmc-bot:mGpBevSEK16Vx3sP -i -H 'X-Requested-By: ambari' -X PUT -d '{"RequestInfo": {"context" :"Start HIVE via REST"}, "Body": {"ServiceInfo": {"state": "STARTED"}}}' https://mtl-hdpmgt81p.cn.ca:8443/api/v1/clusters/prdmchq_hdp/services/HIVE


        sleep 5m

        beeline -f /home/hive/beeline_test.sql > /home/hive/beeline_status.txt
        mail -s "****PRODHQ**** Hive has been restarted, beeline is working " $ADMIN  </home/hive/beeline_status.txt
fi
}

else
     mail -s "****PRODHQ**** Check the HIVE services " $ADMIN <<< 'CHECK HIVE'
fi

